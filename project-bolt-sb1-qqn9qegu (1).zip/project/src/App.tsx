import React, { useState } from 'react';
import { Shield, Lock, AlertTriangle, Brain, Home, ChevronRight } from 'lucide-react';
import HomePage from './components/HomePage';
import PhishingQuiz from './components/PhishingQuiz';
import PasswordStrengthGame from './components/PasswordStrengthGame';
import SecurityTips from './components/SecurityTips';
import AboutPage from './components/AboutPage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage navigateTo={setCurrentPage} />;
      case 'phishing-quiz':
        return <PhishingQuiz navigateTo={setCurrentPage} />;
      case 'password-game':
        return <PasswordStrengthGame navigateTo={setCurrentPage} />;
      case 'security-tips':
        return <SecurityTips navigateTo={setCurrentPage} />;
      case 'about':
        return <AboutPage navigateTo={setCurrentPage} />;
      default:
        return <HomePage navigateTo={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-slate-800 shadow-lg">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div 
            className="flex items-center space-x-2 cursor-pointer" 
            onClick={() => setCurrentPage('home')}
          >
            <Shield className="h-8 w-8 text-cyan-400" />
            <h1 className="text-2xl font-bold text-cyan-400">Cyber Shield</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <button 
              onClick={() => setCurrentPage('home')} 
              className={`flex items-center space-x-1 ${currentPage === 'home' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}
            >
              <Home className="h-5 w-5" />
              <span>Home</span>
            </button>
            <button 
              onClick={() => setCurrentPage('phishing-quiz')} 
              className={`flex items-center space-x-1 ${currentPage === 'phishing-quiz' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}
            >
              <AlertTriangle className="h-5 w-5" />
              <span>Phishing Quiz</span>
            </button>
            <button 
              onClick={() => setCurrentPage('password-game')} 
              className={`flex items-center space-x-1 ${currentPage === 'password-game' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}
            >
              <Lock className="h-5 w-5" />
              <span>Password Game</span>
            </button>
            <button 
              onClick={() => setCurrentPage('security-tips')} 
              className={`flex items-center space-x-1 ${currentPage === 'security-tips' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}
            >
              <Brain className="h-5 w-5" />
              <span>Security Tips</span>
            </button>
            <button 
              onClick={() => setCurrentPage('about')} 
              className={`${currentPage === 'about' ? 'text-cyan-400' : 'text-gray-300 hover:text-white'}`}
            >
              About
            </button>
          </nav>
          <div className="md:hidden">
            {/* Mobile menu button */}
            <button className="text-white">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow">
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Shield className="h-6 w-6 text-cyan-400" />
              <span className="text-lg font-semibold text-cyan-400">Cyber Shield</span>
            </div>
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} Cyber Shield. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;