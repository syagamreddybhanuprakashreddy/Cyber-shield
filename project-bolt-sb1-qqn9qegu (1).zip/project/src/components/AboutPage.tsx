import React from 'react';
import { ArrowLeft, Shield, Users, Target, BookOpen } from 'lucide-react';

interface AboutPageProps {
  navigateTo: (page: string) => void;
}

const AboutPage: React.FC<AboutPageProps> = ({ navigateTo }) => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center">
        <button 
          onClick={() => navigateTo('home')}
          className="mr-4 text-cyan-400 hover:text-cyan-300 flex items-center"
        >
          <ArrowLeft className="h-5 w-5 mr-1" />
          Back
        </button>
        <h2 className="text-3xl font-bold">About Cyber Shield</h2>
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="bg-slate-800 rounded-lg p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center mb-6">
            <Shield className="h-16 w-16 text-cyan-400 mb-4 md:mb-0 md:mr-6" />
            <div>
              <h3 className="text-2xl font-bold mb-2">Our Mission</h3>
              <p className="text-gray-300">
                Cyber Shield is dedicated to empowering individuals with the knowledge and skills needed to protect themselves in the digital world. 
                We believe that cybersecurity education should be accessible, engaging, and practical for everyone.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <div className="bg-slate-700 p-6 rounded-lg">
              <Users className="h-10 w-10 text-blue-400 mb-4" />
              <h4 className="text-lg font-bold mb-2">Who We Are</h4>
              <p className="text-gray-300">
                We are a team of cybersecurity professionals, educators, and developers passionate about making the internet safer through education.
              </p>
            </div>
            <div className="bg-slate-700 p-6 rounded-lg">
              <Target className="h-10 w-10 text-red-400 mb-4" />
              <h4 className="text-lg font-bold mb-2">Our Goal</h4>
              <p className="text-gray-300">
                To reduce cyber attacks by educating users on common threats and empowering them with practical security skills.
              </p>
            </div>
            <div className="bg-slate-700 p-6 rounded-lg">
              <BookOpen className="h-10 w-10 text-green-400 mb-4" />
              <h4 className="text-lg font-bold mb-2">Our Approach</h4>
              <p className="text-gray-300">
                We use interactive games, quizzes, and practical tips to make learning cybersecurity engaging and memorable.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg p-8 mb-8">
          <h3 className="text-2xl font-bold mb-6">Our Team</h3>
          <p className="text-gray-300 mb-6">
            Cyber Shield was created by a dedicated team of six cybersecurity enthusiasts committed to making the digital world safer through education.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">BP</span>
              </div>
              <h4 className="font-bold">Bhanu Prakash</h4>
              <p className="text-sm text-gray-400">Security Specialist</p>
            </div>
            
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">YK</span>
              </div>
              <h4 className="font-bold">Yedukondalu</h4>
              <p className="text-sm text-gray-400">Threat Analyst</p>
            </div>
            
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">CN</span>
              </div>
              <h4 className="font-bold">Choya Nandu</h4>
              <p className="text-sm text-gray-400">Security Engineer</p>
            </div>
            
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">TS</span>
              </div>
              <h4 className="font-bold">Tharun Sai</h4>
              <p className="text-sm text-gray-400">Application Developer</p>
            </div>
            
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">AJ</span>
              </div>
              <h4 className="font-bold">Ajay</h4>
              <p className="text-sm text-gray-400">UI/UX Designer</p>
            </div>
            
            <div className="bg-slate-700 p-4 rounded-lg text-center">
              <div className="bg-cyan-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl font-bold text-cyan-400">SH</span>
              </div>
              <h4 className="font-bold">Srihari</h4>
              <p className="text-sm text-gray-400">Content Strategist</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg p-8 mb-8">
          <h3 className="text-2xl font-bold mb-6">Why Cybersecurity Education Matters</h3>
          
          <div className="space-y-4">
            <p className="text-gray-300">
              In today's interconnected world, cybersecurity is no longer just an IT issue—it's a personal responsibility. 
              The majority of cyber attacks target individuals through social engineering rather than technical exploits.
            </p>
            
            <p className="text-gray-300">
              By understanding common threats like phishing and using strong security practices, you can significantly reduce your risk 
              of becoming a victim. Our interactive approach helps you develop practical skills that you can apply immediately.
            </p>
            
            <div className="bg-slate-700 p-4 rounded-lg mt-6">
              <h4 className="font-bold mb-2">Did you know?</h4>
              <ul className="list-disc list-inside space-y-2 text-gray-300">
                <li>95% of cybersecurity breaches are caused by human error</li>
                <li>Phishing attacks account for more than 80% of reported security incidents</li>
                <li>Using multi-factor authentication can prevent 99.9% of account compromise attacks</li>
                <li>The average cost of a data breach is $4.35 million</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-6">How to Use Cyber Shield</h3>
          
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="bg-cyan-900/30 p-2 rounded-full mr-4 mt-1">
                <span className="flex items-center justify-center h-6 w-6 bg-cyan-500 text-white rounded-full font-bold">1</span>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-1">Take the Phishing Quiz</h4>
                <p className="text-gray-300">
                  Test your ability to identify phishing attempts and learn the warning signs of suspicious emails and messages.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-cyan-900/30 p-2 rounded-full mr-4 mt-1">
                <span className="flex items-center justify-center h-6 w-6 bg-cyan-500 text-white rounded-full font-bold">2</span>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-1">Play the Password Strength Game</h4>
                <p className="text-gray-300">
                  Create and test passwords to understand what makes them strong or weak, and learn best practices for password security.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-cyan-900/30 p-2 rounded-full mr-4 mt-1">
                <span className="flex items-center justify-center h-6 w-6 bg-cyan-500 text-white rounded-full font-bold">3</span>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-1">Review Security Tips</h4>
                <p className="text-gray-300">
                  Browse our comprehensive collection of cybersecurity best practices organized by category.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-cyan-900/30 p-2 rounded-full mr-4 mt-1">
                <span className="flex items-center justify-center h-6 w-6 bg-cyan-500 text-white rounded-full font-bold">4</span>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-1">Apply What You've Learned</h4>
                <p className="text-gray-300">
                  Implement these security practices in your daily digital life to better protect yourself and your information.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 text-center">
            <button 
              onClick={() => navigateTo('home')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold py-3 px-8 rounded-full hover:opacity-90 transition-all shadow-lg"
            >
              Start Learning Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;