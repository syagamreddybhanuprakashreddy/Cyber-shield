import React, { useState } from 'react';
import { AlertTriangle, Check, X, ArrowLeft, ArrowRight } from 'lucide-react';

interface PhishingQuizProps {
  navigateTo: (page: string) => void;
}

interface Question {
  id: number;
  scenario: string;
  image?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const PhishingQuiz: React.FC<PhishingQuizProps> = ({ navigateTo }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const questions: Question[] = [
    {
      id: 1,
      scenario: "You receive an email claiming to be from your bank. It states there's been suspicious activity on your account and you need to verify your information by clicking a link. The email address is 'security-alert@bank-secure-center.com'. What would you do?",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      options: [
        "Click the link and provide the requested information to secure your account",
        "Call your bank's official customer service number to verify if the email is legitimate",
        "Reply to the email asking for more details",
        "Forward the email to friends to see if they received something similar"
      ],
      correctAnswer: 1,
      explanation: "This is a classic phishing attempt. Banks will never ask you to verify information through email links. Always contact your bank directly using the official phone number on their website or the back of your card."
    },
    {
      id: 2,
      scenario: "You receive an email with an attachment from 'HR-Department@yourcompany-hr.net' saying 'Important: Review and Sign Updated Employee Policy'. You weren't expecting this email. What's the best action?",
      image: "https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      options: [
        "Open the attachment to see what policy needs signing",
        "Forward it to your manager to confirm if it's legitimate",
        "Contact HR through official internal channels to verify the email",
        "Reply to the email asking for more information"
      ],
      correctAnswer: 2,
      explanation: "This is suspicious because the domain isn't your company's official domain. Always verify unexpected emails through official internal channels before opening attachments, which could contain malware."
    },
    {
      id: 3,
      scenario: "You receive a text message saying 'Your package delivery was attempted but failed due to incorrect address. Update your delivery preferences here: bit.ly/package-redelivery'. You are expecting a package. What should you do?",
      image: "https://images.unsplash.com/photo-1586769852836-bc069f19e1b6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      options: [
        "Click the link and update your delivery address",
        "Ignore the message completely",
        "Go to the official delivery company's website or app and check your delivery status",
        "Reply asking for more details about the package"
      ],
      correctAnswer: 2,
      explanation: "This is a smishing (SMS phishing) attempt. Legitimate delivery services will identify themselves clearly and typically don't use shortened URLs. Always go directly to the official website or app to check delivery status."
    },
    {
      id: 4,
      scenario: "You receive an email from 'Microsoft Support' saying your account has been compromised and you need to reset your password immediately by clicking a button. The email looks official with Microsoft logos. What's your next step?",
      image: "https://images.unsplash.com/photo-1496171367470-9ed9a91ea931?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      options: [
        "Click the button and reset your password immediately",
        "Check the sender's email address for legitimacy",
        "Ignore the email since you haven't noticed any suspicious activity",
        "Go directly to Microsoft's official website and check your account security status"
      ],
      correctAnswer: 3,
      explanation: "This is likely a phishing attempt. Even if the email looks official with logos, attackers can easily copy these. Always go directly to the official website by typing the URL yourself, not by clicking links in emails."
    },
    {
      id: 5,
      scenario: "You receive a LinkedIn connection request from someone claiming to be a recruiter at a company you'd like to work for. Their profile has minimal information and was created recently. What should you do?",
      image: "https://images.unsplash.com/photo-1611944212129-29977ae1398c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      options: [
        "Accept the connection and share your resume immediately",
        "Accept the connection but be cautious about sharing personal information",
        "Research the person on the company website and other platforms before connecting",
        "Ignore the request completely"
      ],
      correctAnswer: 2,
      explanation: "This could be a social engineering attempt. Always verify the identity of recruiters by checking the company website or calling the company directly. Scammers often pose as recruiters to collect personal information."
    }
  ];

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex);
    if (optionIndex === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedOption(null);
      setShowExplanation(false);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedOption(null);
    setShowExplanation(false);
    setScore(0);
    setQuizCompleted(false);
  };

  const renderQuizContent = () => {
    if (quizCompleted) {
      const percentage = (score / questions.length) * 100;
      let message = "";
      let messageColor = "";

      if (percentage >= 80) {
        message = "Excellent! You have strong phishing detection skills.";
        messageColor = "text-green-400";
      } else if (percentage >= 60) {
        message = "Good job! You're on your way to becoming phishing-aware.";
        messageColor = "text-yellow-400";
      } else {
        message = "Keep practicing! Phishing awareness takes time to develop.";
        messageColor = "text-red-400";
      }

      return (
        <div className="text-center">
          <AlertTriangle className="h-16 w-16 mx-auto text-yellow-400 mb-4" />
          <h2 className="text-2xl font-bold mb-4">Quiz Completed!</h2>
          <p className="text-xl mb-2">Your score: <span className="font-bold">{score}/{questions.length}</span></p>
          <p className={`text-lg font-medium mb-6 ${messageColor}`}>{message}</p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
            <button 
              onClick={restartQuiz}
              className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-6 rounded-lg transition-colors"
            >
              Try Again
            </button>
            <button 
              onClick={() => navigateTo('home')}
              className="bg-slate-700 hover:bg-slate-800 text-white font-bold py-2 px-6 rounded-lg transition-colors"
            >
              Back to Home
            </button>
          </div>
          
          <div className="mt-8 bg-slate-800 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Key Takeaways</h3>
            <ul className="text-left space-y-2">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-1 flex-shrink-0" />
                <span>Always verify the sender's email address and domain</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-1 flex-shrink-0" />
                <span>Never click on suspicious links or download unexpected attachments</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-1 flex-shrink-0" />
                <span>Contact organizations directly through official channels if you're unsure</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-1 flex-shrink-0" />
                <span>Be wary of urgent requests or threats that pressure you to act quickly</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-1 flex-shrink-0" />
                <span>Check for grammar and spelling errors, which are common in phishing attempts</span>
              </li>
            </ul>
          </div>
        </div>
      );
    }

    const question = questions[currentQuestion];

    return (
      <div>
        <div className="mb-6 flex justify-between items-center">
          <span className="text-sm font-medium text-gray-400">Question {currentQuestion + 1} of {questions.length}</span>
          <div className="w-32 bg-slate-700 rounded-full h-2">
            <div 
              className="bg-cyan-400 h-2 rounded-full" 
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg p-6 mb-6">
          <h3 className="text-xl font-bold mb-4">Scenario:</h3>
          <p className="text-gray-300 mb-4">{question.scenario}</p>
          {question.image && (
            <div className="mb-4">
              <img 
                src={question.image} 
                alt="Phishing scenario illustration" 
                className="rounded-lg w-full h-48 object-cover"
              />
            </div>
          )}
        </div>

        <div className="mb-6">
          <h3 className="text-xl font-bold mb-4">What would you do?</h3>
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                disabled={showExplanation}
                className={`w-full text-left p-4 rounded-lg transition-colors ${
                  selectedOption === index 
                    ? selectedOption === question.correctAnswer
                      ? 'bg-green-600/20 border border-green-500'
                      : 'bg-red-600/20 border border-red-500'
                    : 'bg-slate-700 hover:bg-slate-600'
                } ${showExplanation ? 'cursor-default' : 'cursor-pointer'}`}
              >
                <div className="flex items-start">
                  {showExplanation && index === selectedOption && (
                    <span className="mr-2 mt-0.5">
                      {index === question.correctAnswer ? (
                        <Check className="h-5 w-5 text-green-500" />
                      ) : (
                        <X className="h-5 w-5 text-red-500" />
                      )}
                    </span>
                  )}
                  <span>{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {showExplanation && (
          <div className="bg-slate-800 border-l-4 border-cyan-500 p-4 rounded-r-lg mb-6">
            <h4 className="font-bold mb-2">Explanation:</h4>
            <p>{question.explanation}</p>
          </div>
        )}

        <div className="flex justify-between">
          <button
            onClick={handlePreviousQuestion}
            disabled={currentQuestion === 0}
            className={`flex items-center ${
              currentQuestion === 0 
                ? 'text-gray-500 cursor-not-allowed' 
                : 'text-cyan-400 hover:text-cyan-300'
            }`}
          >
            <ArrowLeft className="h-5 w-5 mr-1" />
            Previous
          </button>
          
          {showExplanation ? (
            <button
              onClick={handleNextQuestion}
              className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-6 rounded-lg transition-colors flex items-center"
            >
              {currentQuestion < questions.length - 1 ? (
                <>Next <ArrowRight className="h-5 w-5 ml-1" /></>
              ) : (
                'See Results'
              )}
            </button>
          ) : (
            <div></div> // Empty div to maintain flex spacing
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8 flex items-center">
          <button 
            onClick={() => navigateTo('home')}
            className="mr-4 text-cyan-400 hover:text-cyan-300 flex items-center"
          >
            <ArrowLeft className="h-5 w-5 mr-1" />
            Back
          </button>
          <h2 className="text-3xl font-bold flex items-center">
            <AlertTriangle className="h-7 w-7 text-yellow-400 mr-2" />
            Phishing Detection Quiz
          </h2>
        </div>
        
        {renderQuizContent()}
      </div>
    </div>
  );
};

export default PhishingQuiz;