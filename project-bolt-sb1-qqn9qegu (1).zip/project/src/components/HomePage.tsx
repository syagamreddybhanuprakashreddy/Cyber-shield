import React from 'react';
import { Shield, AlertTriangle, Lock, Brain, ChevronRight } from 'lucide-react';

interface HomePageProps {
  navigateTo: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ navigateTo }) => {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="py-12 md:py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <Shield className="h-20 w-20 mx-auto text-cyan-400 mb-6" />
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            Protect Yourself in the Digital World
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Learn essential cybersecurity skills through interactive games and quizzes.
            Become cyber-smart and shield yourself from digital threats.
          </p>
          <button 
            onClick={() => navigateTo('phishing-quiz')}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold py-3 px-8 rounded-full hover:opacity-90 transition-all shadow-lg"
          >
            Start Learning
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Interactive Security Games</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Phishing Quiz Card */}
          <div className="bg-slate-800 rounded-xl p-6 shadow-lg hover:shadow-cyan-900/20 transition-all hover:-translate-y-1">
            <div className="bg-cyan-900/30 p-3 rounded-full w-fit mb-4">
              <AlertTriangle className="h-8 w-8 text-yellow-400" />
            </div>
            <h3 className="text-xl font-bold mb-3">Phishing Detection Quiz</h3>
            <p className="text-gray-300 mb-4">
              Test your ability to identify phishing attempts and suspicious emails. Learn the red flags to watch for.
            </p>
            <button 
              onClick={() => navigateTo('phishing-quiz')}
              className="flex items-center text-cyan-400 font-medium hover:text-cyan-300"
            >
              Start Quiz <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>

          {/* Password Strength Game Card */}
          <div className="bg-slate-800 rounded-xl p-6 shadow-lg hover:shadow-cyan-900/20 transition-all hover:-translate-y-1">
            <div className="bg-cyan-900/30 p-3 rounded-full w-fit mb-4">
              <Lock className="h-8 w-8 text-green-400" />
            </div>
            <h3 className="text-xl font-bold mb-3">Password Strength Game</h3>
            <p className="text-gray-300 mb-4">
              Create strong, uncrackable passwords and learn the principles behind password security.
            </p>
            <button 
              onClick={() => navigateTo('password-game')}
              className="flex items-center text-cyan-400 font-medium hover:text-cyan-300"
            >
              Play Game <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>

          {/* Security Tips Card */}
          <div className="bg-slate-800 rounded-xl p-6 shadow-lg hover:shadow-cyan-900/20 transition-all hover:-translate-y-1">
            <div className="bg-cyan-900/30 p-3 rounded-full w-fit mb-4">
              <Brain className="h-8 w-8 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold mb-3">Security Best Practices</h3>
            <p className="text-gray-300 mb-4">
              Learn essential cybersecurity tips and best practices to keep your digital life secure.
            </p>
            <button 
              onClick={() => navigateTo('security-tips')}
              className="flex items-center text-cyan-400 font-medium hover:text-cyan-300"
            >
              View Tips <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-slate-800/50 rounded-2xl my-8 p-8">
        <h2 className="text-3xl font-bold text-center mb-12">Why Cybersecurity Matters</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <p className="text-4xl font-bold text-cyan-400 mb-2">80%</p>
            <p className="text-gray-300">of breaches involve weak passwords</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-cyan-400 mb-2">3.4B</p>
            <p className="text-gray-300">phishing emails sent daily</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-cyan-400 mb-2">$4.35M</p>
            <p className="text-gray-300">average cost of a data breach</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-cyan-400 mb-2">95%</p>
            <p className="text-gray-300">of breaches due to human error</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-6">Ready to Strengthen Your Cyber Defense?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Start with our interactive games and become cyber-smart today!
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button 
              onClick={() => navigateTo('phishing-quiz')}
              className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Try Phishing Quiz
            </button>
            <button 
              onClick={() => navigateTo('password-game')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Test Password Strength
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;