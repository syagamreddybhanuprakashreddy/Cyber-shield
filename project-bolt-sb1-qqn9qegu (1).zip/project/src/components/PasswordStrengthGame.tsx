import React, { useState, useEffect } from 'react';
import { Lock, ArrowLeft, Check, X, Eye, EyeOff, RefreshCw } from 'lucide-react';

interface PasswordStrengthGameProps {
  navigateTo: (page: string) => void;
}

const PasswordStrengthGame: React.FC<PasswordStrengthGameProps> = ({ navigateTo }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<string[]>([]);
  const [strengthLevel, setStrengthLevel] = useState('');
  const [strengthColor, setStrengthColor] = useState('');
  const [showTips, setShowTips] = useState(false);

  // Password criteria
  const criteria = [
    { id: 'length', label: 'At least 12 characters long', test: (pwd: string) => pwd.length >= 12, points: 20 },
    { id: 'uppercase', label: 'Contains uppercase letters', test: (pwd: string) => /[A-Z]/.test(pwd), points: 15 },
    { id: 'lowercase', label: 'Contains lowercase letters', test: (pwd: string) => /[a-z]/.test(pwd), points: 15 },
    { id: 'numbers', label: 'Contains numbers', test: (pwd: string) => /[0-9]/.test(pwd), points: 15 },
    { id: 'special', label: 'Contains special characters', test: (pwd: string) => /[^A-Za-z0-9]/.test(pwd), points: 15 },
    { id: 'noSequences', label: 'No common sequences (123, abc)', test: (pwd: string) => !/(123|abc|qwerty|password)/i.test(pwd), points: 10 },
    { id: 'noRepeats', label: 'No repeating characters (aaa, 111)', test: (pwd: string) => !/(.)\1{2,}/.test(pwd), points: 10 }
  ];

  // Common password patterns to check against
  const commonPasswords = [
    'password', '123456', 'qwerty', 'admin', 'welcome', 
    'letmein', 'monkey', 'football', 'dragon', 'baseball',
    'sunshine', 'princess', 'superman', 'trustno1'
  ];

  useEffect(() => {
    evaluatePassword();
  }, [password]);

  const evaluatePassword = () => {
    if (!password) {
      setScore(0);
      setFeedback([]);
      setStrengthLevel('');
      setStrengthColor('');
      return;
    }

    let newScore = 0;
    const passedCriteria: string[] = [];
    const failedCriteria: string[] = [];

    // Check each criterion
    criteria.forEach(criterion => {
      if (criterion.test(password)) {
        newScore += criterion.points;
        passedCriteria.push(criterion.label);
      } else {
        failedCriteria.push(criterion.label);
      }
    });

    // Penalty for common passwords
    if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
      newScore = Math.max(0, newScore - 30);
      failedCriteria.push('Password contains common patterns');
    }

    // Set strength level based on score
    let level = '';
    let color = '';
    if (newScore >= 90) {
      level = 'Very Strong';
      color = 'text-green-500';
    } else if (newScore >= 70) {
      level = 'Strong';
      color = 'text-green-400';
    } else if (newScore >= 50) {
      level = 'Moderate';
      color = 'text-yellow-400';
    } else if (newScore >= 30) {
      level = 'Weak';
      color = 'text-orange-400';
    } else {
      level = 'Very Weak';
      color = 'text-red-500';
    }

    setScore(newScore);
    setFeedback(failedCriteria);
    setStrengthLevel(level);
    setStrengthColor(color);
  };

  const generateRandomPassword = () => {
    const length = 16;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+';
    let newPassword = '';
    
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * charset.length);
      newPassword += charset[randomIndex];
    }
    
    setPassword(newPassword);
  };

  const calculateTimeToHack = () => {
    if (score < 30) return 'Instantly';
    if (score < 50) return 'A few minutes to hours';
    if (score < 70) return 'A few days to weeks';
    if (score < 90) return 'A few months to years';
    return 'Centuries or more';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8 flex items-center">
          <button 
            onClick={() => navigateTo('home')}
            className="mr-4 text-cyan-400 hover:text-cyan-300 flex items-center"
          >
            <ArrowLeft className="h-5 w-5 mr-1" />
            Back
          </button>
          <h2 className="text-3xl font-bold flex items-center">
            <Lock className="h-7 w-7 text-green-400 mr-2" />
            Password Strength Game
          </h2>
        </div>

        <div className="bg-slate-800 rounded-lg p-6 mb-8">
          <p className="text-gray-300 mb-4">
            Create a strong password and see how it scores. The stronger your password, the better protected your accounts will be from hackers.
          </p>
          
          <div className="relative mb-6">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter a password"
              className="w-full bg-slate-700 text-white px-4 py-3 pr-12 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>

          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Password Strength:</span>
            <span className={`font-bold ${strengthColor}`}>{strengthLevel || 'Not Rated'}</span>
          </div>

          <div className="w-full bg-slate-700 rounded-full h-2.5 mb-6">
            <div 
              className={`h-2.5 rounded-full ${
                score >= 90 ? 'bg-green-500' : 
                score >= 70 ? 'bg-green-400' : 
                score >= 50 ? 'bg-yellow-400' : 
                score >= 30 ? 'bg-orange-400' : 
                'bg-red-500'
              }`} 
              style={{ width: `${Math.min(100, score)}%` }}
            ></div>
          </div>

          {password && (
            <div className="mb-6">
              <p className="mb-2">
                <span className="font-medium">Score:</span> {score}/100
              </p>
              <p className="mb-4">
                <span className="font-medium">Estimated time to crack:</span> {calculateTimeToHack()}
              </p>
              
              {feedback.length > 0 && (
                <div className="bg-slate-700 p-4 rounded-lg">
                  <h4 className="font-bold mb-2 text-yellow-400">Suggestions to improve:</h4>
                  <ul className="space-y-1">
                    {feedback.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <X className="h-4 w-4 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={generateRandomPassword}
              className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Generate Strong Password
            </button>
            <button
              onClick={() => setShowTips(!showTips)}
              className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
              {showTips ? 'Hide Tips' : 'Show Password Tips'}
            </button>
          </div>
        </div>

        {showTips && (
          <div className="bg-slate-800 rounded-lg p-6 mb-8">
            <h3 className="text-xl font-bold mb-4">Password Security Tips</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Use a passphrase</p>
                  <p className="text-sm text-gray-300">Combine multiple random words with numbers and symbols (e.g., "Horse-Battery42-Staple!")</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Make it long</p>
                  <p className="text-sm text-gray-300">Longer passwords are harder to crack. Aim for at least 12-16 characters.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Use a password manager</p>
                  <p className="text-sm text-gray-300">Tools like LastPass, 1Password, or Bitwarden can generate and store strong unique passwords.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Enable two-factor authentication (2FA)</p>
                  <p className="text-sm text-gray-300">Add an extra layer of security beyond just your password.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Use unique passwords</p>
                  <p className="text-sm text-gray-300">Never reuse passwords across different accounts.</p>
                </div>
              </li>
              <li className="flex items-start">
                <X className="h-5 w-5 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Avoid personal information</p>
                  <p className="text-sm text-gray-300">Don't use names, birthdays, or information that could be found on social media.</p>
                </div>
              </li>
              <li className="flex items-start">
                <X className="h-5 w-5 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Don't use common substitutions</p>
                  <p className="text-sm text-gray-300">Replacing 'a' with '@' or 'e' with '3' is predictable and easily cracked.</p>
                </div>
              </li>
            </ul>
          </div>
        )}

        <div className="bg-slate-800 rounded-lg p-6">
          <h3 className="text-xl font-bold mb-4">Why Password Strength Matters</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-slate-700 p-4 rounded-lg">
              <h4 className="font-bold mb-2 text-red-400">Weak Password Risks:</h4>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <X className="h-4 w-4 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Account takeovers and identity theft</span>
                </li>
                <li className="flex items-start">
                  <X className="h-4 w-4 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Financial loss from compromised accounts</span>
                </li>
                <li className="flex items-start">
                  <X className="h-4 w-4 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Access to your personal data and communications</span>
                </li>
                <li className="flex items-start">
                  <X className="h-4 w-4 text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Attackers can use your accounts to target others</span>
                </li>
              </ul>
            </div>
            <div className="bg-slate-700 p-4 rounded-lg">
              <h4 className="font-bold mb-2 text-green-400">Strong Password Benefits:</h4>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Significantly increased security for your accounts</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Protection against automated brute force attacks</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Peace of mind knowing your data is better protected</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Reduced risk of becoming a victim of cybercrime</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordStrengthGame;